
function showPopup(room) {
    document.getElementById(room).style.display = 'block';
}

function closePopup() {
    const popups = document.querySelectorAll('.popup');
    popups.forEach(popup => {
        popup.style.display = 'none';
    });
}
